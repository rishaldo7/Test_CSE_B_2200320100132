Run: pip install -r requirements.txt && streamlit run app.py
Pre-trained RF model included. Report proposed model is LSTM: MAE 5.2 MW, RMSE 6.8 MW.
