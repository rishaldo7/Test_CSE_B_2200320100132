import numpy as np
import pandas as pd
FEATURE_COLUMNS=['hour_sin','hour_cos','dow_sin','dow_cos','month_sin','month_cos','is_weekend','lag_1','lag_2','lag_3','lag_4','lag_5','lag_6','lag_24','lag_168','roll_mean_3','roll_mean_24','roll_std_24','roll_max_24','roll_min_24']
def build_features(df):
    data=df.copy(); idx=data.index
    data['hour_sin']=np.sin(2*np.pi*idx.hour/24); data['hour_cos']=np.cos(2*np.pi*idx.hour/24); data['dow_sin']=np.sin(2*np.pi*idx.dayofweek/7); data['dow_cos']=np.cos(2*np.pi*idx.dayofweek/7); data['month_sin']=np.sin(2*np.pi*idx.month/12); data['month_cos']=np.cos(2*np.pi*idx.month/12); data['is_weekend']=(idx.dayofweek>=5).astype(int)
    for lag in [1,2,3,4,5,6,24,168]: data[f'lag_{lag}']=data['demand_mw'].shift(lag)
    data['roll_mean_3']=data['demand_mw'].shift(1).rolling(3).mean(); data['roll_mean_24']=data['demand_mw'].shift(1).rolling(24).mean(); data['roll_std_24']=data['demand_mw'].shift(1).rolling(24).std(); data['roll_max_24']=data['demand_mw'].shift(1).rolling(24).max(); data['roll_min_24']=data['demand_mw'].shift(1).rolling(24).min()
    data=data.dropna(); return data[FEATURE_COLUMNS],data['demand_mw'],data
def make_next_hour_features(clean_df):
    next_time=clean_df.index.max()+pd.Timedelta(hours=1); temp=clean_df.copy(); temp.loc[next_time,'demand_mw']=temp['demand_mw'].iloc[-1]; X,_,_=build_features(temp); return X.tail(1),next_time
