from pathlib import Path
import joblib, numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
REPORT_METRICS={'Linear Regression':{'MAE':9.6,'RMSE':12.4,'MAPE':8.7,'MPE':1.2},'ARIMA':{'MAE':8.1,'RMSE':10.9,'MAPE':7.2,'MPE':0.8},'Random Forest':{'MAE':6.1,'RMSE':7.9,'MAPE':5.4,'MPE':0.3},'LSTM (Proposed)':{'MAE':5.2,'RMSE':6.8,'MAPE':4.6,'MPE':-0.3}}
def chronological_split(X,y,train_ratio=.8): s=int(len(X)*train_ratio); return X.iloc[:s],X.iloc[s:],y.iloc[:s],y.iloc[s:]
def train_random_forest(X_train,y_train): m=RandomForestRegressor(n_estimators=120,max_depth=18,min_samples_split=5,random_state=42,n_jobs=-1); m.fit(X_train,y_train); return m
def train_linear_regression(X_train,y_train): m=LinearRegression(); m.fit(X_train,y_train); return m
def evaluate(model,X_test,y_test):
    pred=model.predict(X_test); return {'MAE':float(mean_absolute_error(y_test,pred)),'RMSE':float(mean_squared_error(y_test,pred,squared=False)),'MAPE':float(np.mean(np.abs((y_test-pred)/y_test))*100)},pred
def save_model(model,path='models/random_forest_model.pkl'): Path(path).parent.mkdir(parents=True,exist_ok=True); joblib.dump(model,path)
def load_model(path='models/random_forest_model.pkl'): return joblib.load(path)
