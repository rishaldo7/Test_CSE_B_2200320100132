import pandas as pd

def load_demand_csv(path_or_buffer):
    df=pd.read_csv(path_or_buffer)
    if 'datetime' not in df.columns or 'demand_mw' not in df.columns: raise ValueError('CSV must contain datetime and demand_mw')
    df['datetime']=pd.to_datetime(df['datetime']); df=df.sort_values('datetime').drop_duplicates('datetime').set_index('datetime')
    df['demand_mw']=pd.to_numeric(df['demand_mw'],errors='coerce'); return df

def clean_data(df):
    data=df.copy().asfreq('H'); data['demand_mw']=data['demand_mw'].interpolate(limit=3).fillna(data['demand_mw'].median())
    q1,q3=data['demand_mw'].quantile([.25,.75]); iqr=q3-q1; data['demand_mw']=data['demand_mw'].clip(q1-1.5*iqr,q3+1.5*iqr); return data
