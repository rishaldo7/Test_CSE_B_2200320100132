import matplotlib.pyplot as plt
def plot_actual_vs_predicted(index,actual,predicted):
    fig,ax=plt.subplots(figsize=(10,4)); ax.plot(index,actual,label='Actual Demand'); ax.plot(index,predicted,label='Predicted Demand'); ax.set_title('Actual vs Predicted Electricity Demand'); ax.set_xlabel('Time'); ax.set_ylabel('Demand (MW)'); ax.legend(); fig.tight_layout(); return fig
def plot_report_metrics(metrics):
    names=list(metrics.keys()); mae=[metrics[n]['MAE'] for n in names]; rmse=[metrics[n]['RMSE'] for n in names]; x=range(len(names)); fig,ax=plt.subplots(figsize=(9,4)); ax.bar([i-.2 for i in x],mae,width=.4,label='MAE'); ax.bar([i+.2 for i in x],rmse,width=.4,label='RMSE'); ax.set_xticks(list(x)); ax.set_xticklabels(names,rotation=20,ha='right'); ax.set_ylabel('Error (MW)'); ax.set_title('Performance Comparison Across Models'); ax.legend(); fig.tight_layout(); return fig
