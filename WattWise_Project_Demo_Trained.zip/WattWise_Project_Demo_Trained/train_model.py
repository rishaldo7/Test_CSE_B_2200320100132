from src.preprocessing import load_demand_csv, clean_data
from src.features import build_features
from src.model_utils import chronological_split, train_random_forest, evaluate, save_model
df=load_demand_csv('data/sample_demand.csv'); clean=clean_data(df); X,y,_=build_features(clean); Xtr,Xte,ytr,yte=chronological_split(X,y); model=train_random_forest(Xtr,ytr); print(evaluate(model,Xte,yte)[0]); save_model(model)
