
# WattWise Trained Demo

This version already includes a trained `models/random_forest_model.pkl` for instant next-hour prediction.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

The dashboard also shows report benchmark metrics where LSTM is the proposed best model: MAE 5.2 MW, RMSE 6.8 MW, MAPE 4.6%.
