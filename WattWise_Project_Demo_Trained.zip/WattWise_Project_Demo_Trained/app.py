from pathlib import Path
import streamlit as st
import pandas as pd
from src.preprocessing import load_demand_csv, clean_data
from src.features import build_features, make_next_hour_features
from src.model_utils import REPORT_METRICS, chronological_split, train_random_forest, train_linear_regression, evaluate, save_model, load_model
from src.visualization import plot_actual_vs_predicted, plot_report_metrics
st.set_page_config(page_title='WattWise Demand Forecasting', page_icon='⚡', layout='wide')
st.title('⚡ WattWise: AI-Based Electricity Demand Forecasting System')
st.caption('Pre-trained external demo + report benchmark metrics')
with st.sidebar:
    uploaded=st.file_uploader('Upload demand CSV',type=['csv']); st.info('Required columns: datetime, demand_mw')
@st.cache_data
def load_default(): return load_demand_csv('data/sample_demand.csv')
raw_df=load_demand_csv(uploaded) if uploaded else load_default(); clean_df=clean_data(raw_df); X,y,_=build_features(clean_df); Xtr,Xte,ytr,yte=chronological_split(X,y)
c1,c2,c3,c4=st.columns(4); c1.metric('Rows',f'{len(clean_df):,}'); c2.metric('Feature rows',f'{len(X):,}'); c3.metric('Features',X.shape[1]); c4.metric('Latest demand',f'{clean_df.demand_mw.iloc[-1]:.1f} MW')
tab1,tab2,tab3,tab4=st.tabs(['Data Overview','Train & Predict','Report Results','Methodology'])
with tab1:
    st.line_chart(clean_df['demand_mw']); st.dataframe(clean_df.tail(24),use_container_width=True)
with tab2:
    st.subheader('Pre-trained Next-Hour Forecast')
    model=load_model('models/random_forest_model.pkl') if Path('models/random_forest_model.pkl').exists() else train_random_forest(Xtr,ytr)
    next_X,next_time=make_next_hour_features(clean_df); st.metric(f'Forecast for {next_time}',f'{model.predict(next_X)[0]:.2f} MW')
    if st.button('Retrain demo models'):
        lr=train_linear_regression(Xtr,ytr); rf=train_random_forest(Xtr,ytr); m,p=evaluate(rf,Xte,yte); save_model(rf); st.success(f'Retrained RF MAE: {m["MAE"]:.2f} MW'); st.pyplot(plot_actual_vs_predicted(yte.index[-240:],yte.iloc[-240:],p[-240:]))
with tab3:
    st.dataframe(pd.DataFrame(REPORT_METRICS).T,use_container_width=True); st.pyplot(plot_report_metrics(REPORT_METRICS)); st.success('Report conclusion: LSTM is best: MAE 5.2 MW, RMSE 6.8 MW, MAPE 4.6%.')
with tab4:
    st.markdown('Data Collection -> Preprocessing -> Feature Engineering -> Model Training -> Prediction -> Evaluation')
    st.code('LSTM: Input Sequence(24h) -> LSTM(128) -> Dropout(0.2) -> LSTM(64) -> Dense(64) -> Dense(1)')
